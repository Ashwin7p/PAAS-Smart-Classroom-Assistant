import face_recognition

def open_encoding(filename):
	file = open(filename, "rb")
	data = pickle.load(file)
	file.close()
	return data


open_encoding("encoding")

